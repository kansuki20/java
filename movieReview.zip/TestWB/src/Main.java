import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;


public class Main extends JFrame {

	private JPanel contentPane;
	private JTextField txtMain;
	private JTextField txtId;
	private JTextField txtPassword;
	private JTextField txtSearch;
	private JButton btMember;
	private JButton btSearch;

	private JScrollPane scrollPane;
	private JTable table;

	static String idStr = null;
	static String name = null;
	static int movieNum	= 0;
	private JButton btnNewButton_1;
	
	public Main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		txtMain = new JTextField();
		txtMain.setBackground(Color.WHITE);
		txtMain.setEnabled(false);
		txtMain.setFont(new Font("����", Font.BOLD, 30));
		txtMain.setHorizontalAlignment(SwingConstants.CENTER);
		txtMain.setText("Main");
		txtMain.setBounds(189, 10, 166, 35);
		contentPane.add(txtMain);
		txtMain.setColumns(10);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WBMain.dbConnect();
				try {
					WBMain.query("select", "select * from member where id = '"+txtId.getText()+"'");
					if(WBMain.rs.next() == false){
						JOptionPane.showMessageDialog(null, "���̵� Ȯ�����ּ���");
					} else {
						if (WBMain.rs.getString(2).equals(txtPassword.getText())) {
							System.out.println("�α��� ����");
							idStr = WBMain.rs.getString("id"); // static���� idStr�� ���� id ���� -> Search Ŭ�������� �������� ���ƿ� �� ���
							name = WBMain.rs.getString("name");
							
							setVisible(false);
							new Login_Main().setVisible(true);
						} else {
							JOptionPane.showMessageDialog(null, "�н����带 Ȯ�����ּ���");
						}
					}	
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		//---------------------------------------------------------------
		/*try {
			WBMain.query("select", "select * from member where id = '"+Main.idStr+"'");
			while(WBMain.rs.next()) {
				Main.name = WBMain.rs.getString("name");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		//----------------------------------------------------------------
		
		btnNewButton.setFont(new Font("����", Font.BOLD, 15));
		btnNewButton.setBounds(432, 135, 96, 21);
		contentPane.add(btnNewButton);
		
		txtId = new JTextField();
		txtId.setText("id");
		txtId.setBounds(432, 76, 96, 21);
		contentPane.add(txtId);
		txtId.setColumns(10);
		txtId.addMouseListener(new MouseListener() {
			@Override
			public void mousePressed(MouseEvent e) {
				txtId.setText("");
			}
			@Override
			public void mouseClicked(MouseEvent e) {
			}
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
		});
		
		txtPassword = new JTextField();
		txtPassword.setText("ps");
		txtPassword.setColumns(10);
		txtPassword.setBounds(432, 104, 96, 21);
		contentPane.add(txtPassword);
		txtPassword.addMouseListener(new MouseListener() {
			@Override
			public void mousePressed(MouseEvent e) {
				txtPassword.setText("");
			}
			@Override
			public void mouseClicked(MouseEvent e) {
			}
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
		});
		
		txtSearch = new JTextField();
		txtSearch.addMouseListener(new MouseListener() {
			@Override
			public void mousePressed(MouseEvent e) {
				txtSearch.setText("");
			}
			@Override
			public void mouseClicked(MouseEvent e) {
			}
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
		});
		txtSearch.setText("\uAC80\uC0C9\uD560 \uB0B4\uC6A9\uC744 \uC785\uB825\uD558\uC138\uC694.");
		txtSearch.setBounds(110, 76, 240, 26);
		contentPane.add(txtSearch);
		txtSearch.setColumns(10);
		
		
		String[] head = {"��ȭ��", "����", "���� ����", "������"};
		DefaultTableModel model = new DefaultTableModel(head,0);
		table = new JTable(model);
		table.addMouseListener(new MouseListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String search = (String) table.getValueAt(table.getSelectedRow(), 0);
				WBMain.dbConnect();
				try {
					WBMain.query("select", "select * from movie where movieName = '"+search+"'");
					while(WBMain.rs.next()) 
						movieNum = WBMain.rs.getInt("movieNumber");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				setVisible(false);
				new Information().setVisible(true);
			}
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mousePressed(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
		});
		
		//��ũ�� ����
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 131, 412, 262);
		scrollPane.setBackground(Color.white);
		contentPane.add(scrollPane);
		
		
		//-----------------------------------���̽� ����--------------------
		Choice choice = new Choice();
		choice.setBounds(34, 79, 140, 18);
		choice.add("��ȭ��");
		choice.add("����");
		contentPane.add(choice);
		//-----------------------------------���̽� ����--------------------
		
		btMember = new JButton("\uD68C\uC6D0\uAC00\uC785"); //ȸ������
		btMember.setBackground(Color.WHITE);
		btMember.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Membership().setVisible(true);
			}
		});
		btMember.setFont(new Font("����", Font.BOLD, 15));
		btMember.setBounds(432, 166, 96, 21);
		contentPane.add(btMember);
		
		btSearch = new JButton("\uAC80\uC0C9");
		btSearch.setBackground(Color.WHITE);
		btSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WBMain.dbConnect();
				model.setNumRows(0);
				if (choice.getSelectedItem() == "��ȭ��") {
					try {
						WBMain.query("select", "select * from movie where movieName like '%"+txtSearch.getText()+"%'");
						while(WBMain.rs.next()) {
							model.addRow(new Object[] {
								WBMain.rs.getString("movieName"),
								WBMain.rs.getString("director"),
								WBMain.rs.getString("country"),
								WBMain.rs.getString("releaseDate"),
							});
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				} else if (choice.getSelectedItem() == "����") {
					try {
						WBMain.query("select", "select * from movie where director like '%"+txtSearch.getText()+"%'");
						while(WBMain.rs.next()) {
							model.addRow(new Object[] {
								WBMain.rs.getString("movieName"),
								WBMain.rs.getString("director"),
								WBMain.rs.getString("country"),
								WBMain.rs.getString("releaseDate"),
							});
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				WBMain.dbDis();
			}
		});
		btSearch.setBounds(349, 75, 59, 26);
		contentPane.add(btSearch);
		
		btnNewButton_1 = new JButton("New button");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Enter().setVisible(true);
			}
		});
		btnNewButton_1.setBounds(432, 282, 93, 23);
		contentPane.add(btnNewButton_1);
		
	}
}
