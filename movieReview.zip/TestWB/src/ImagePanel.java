import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class ImagePanel extends JPanel {
	static String imgLink = "C:/Users/kansu/eclipse-workspace/TestWB/image/miyazaki_hayao/" + WBMain.posterLink;
	static ImageIcon icon = new ImageIcon(imgLink);
	static Image img = icon.getImage();
	static Image changeImg = img.getScaledInstance(265, 365, Image.SCALE_SMOOTH);
	static ImageIcon changeIcon = new ImageIcon(changeImg);
	
	
	
	public ImagePanel (Image img) {
		changeImg = img;
		setSize(new Dimension(img.getWidth(null), img.getHeight(null)));
		setLayout(null);
	}
	
	public void paintComponent (Graphics g) {
		g.drawImage(changeImg, 0, 0, null);
	}
}