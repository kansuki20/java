import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.net.URL;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class Information extends JFrame {

	private JPanel contentPane;
	private JPanel pnPoster;
	
	private JTable table;
	private JScrollPane scrollPane;
	
	private JTextField txtInformation;
	private JTextField txtMvName;
	private JTextField txtDirector;
	private JTextField txtGenre;
	private JTextField txtDate;
	private JTextField txtRTime;
	private JTextField txtCountry;
	private JTextField txtRating;
	private JTextArea txtPlot;
	
	
	
	//----------------�̹��� �����
	
	static String movieName = null;
	static String search = null;

	
	public Information() {
		//----------------------------
		try {
			WBMain.query("select", "select * from movie where movieNumber like '"+Main.movieNum+"'");
			while(WBMain.rs.next())
				WBMain.posterLink = WBMain.rs.getString("posterLink");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		//--------------------------------------------
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 700);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JPanel paneInfo = new JPanel();
		paneInfo.setBackground(Color.WHITE);
		paneInfo.setBounds(10, 70, 618, 385);
		contentPane.add(paneInfo);
		paneInfo.setLayout(null);
		
		ImagePanel poster = new ImagePanel(ImagePanel.changeIcon.getImage());
		poster.setBounds(10, 10, 265, 365);
		paneInfo.add(poster);
		/*pnPoster = new JPanel();
		pnPoster.setBounds(10, 10, 265, 365);
		paneInfo.add(pnPoster);*/
		
		txtMvName = new JTextField();
		txtMvName.setForeground(SystemColor.desktop);
		txtMvName.setBackground(Color.WHITE);
		txtMvName.setHorizontalAlignment(SwingConstants.CENTER);
		txtMvName.setBounds(350, 10, 186, 25);
		paneInfo.add(txtMvName);
		txtMvName.setColumns(10);
		
		txtDirector = new JTextField();
		txtDirector.setHorizontalAlignment(SwingConstants.CENTER);
		txtDirector.setColumns(10);
		txtDirector.setBackground(Color.WHITE);
		txtDirector.setBounds(350, 45, 186, 25);
		paneInfo.add(txtDirector);
		
		txtGenre = new JTextField();
		txtGenre.setHorizontalAlignment(SwingConstants.CENTER);
		txtGenre.setColumns(10);
		txtGenre.setBackground(Color.WHITE);
		txtGenre.setBounds(350, 80, 186, 25);
		paneInfo.add(txtGenre);
		
		txtDate = new JTextField();
		txtDate.setHorizontalAlignment(SwingConstants.CENTER);
		txtDate.setColumns(10);
		txtDate.setBackground(Color.WHITE);
		txtDate.setBounds(350, 112, 88, 25);
		paneInfo.add(txtDate);
		
		txtRTime = new JTextField();
		txtRTime.setHorizontalAlignment(SwingConstants.CENTER);
		txtRTime.setColumns(10);
		txtRTime.setBackground(Color.WHITE);
		txtRTime.setBounds(448, 112, 88, 25);
		paneInfo.add(txtRTime);
		
		txtCountry = new JTextField();
		txtCountry.setHorizontalAlignment(SwingConstants.CENTER);
		txtCountry.setColumns(10);
		txtCountry.setBackground(Color.WHITE);
		txtCountry.setBounds(350, 147, 88, 25);
		paneInfo.add(txtCountry);
		
		txtRating = new JTextField();
		txtRating.setHorizontalAlignment(SwingConstants.CENTER);
		txtRating.setColumns(10);
		txtRating.setBackground(Color.WHITE);
		txtRating.setBounds(448, 147, 88, 25);
		paneInfo.add(txtRating);
		
		txtPlot = new JTextArea();
		txtPlot.setLineWrap(true);

		
		JScrollPane panelPlot = new JScrollPane(txtPlot);
		panelPlot.setBounds(279, 182, 329, 193);
		panelPlot.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); // ���� ��ũ�� �Ⱦ���
		

		paneInfo.add(panelPlot);
		
		JButton btStatus = new JButton("\uB098\uC758 \uC815\uBCF4");
		btStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WBMain.dbConnect();
				try {
					WBMain.query("select", "select * from member where id = '"+Main.idStr+"'");
					if(WBMain.rs.next() == false){
						JOptionPane.showMessageDialog(null, "�α����� ���ּ���.");
						WBMain.dbDis();
					} else {
						setVisible(false);
						new MyStatus().setVisible(true);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btStatus.setBackground(Color.WHITE);
		btStatus.setBounds(528, 0, 100, 29);
		contentPane.add(btStatus);
		
		JButton btMain = new JButton("Main");
		btMain.setBackground(Color.WHITE);
		btMain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WBMain.dbConnect();
				try {
					WBMain.query("select", "select * from member where id = '"+Main.idStr+"'");
					if(WBMain.rs.next() == false){
						setVisible(false);
						new Main().setVisible(true);
						WBMain.dbDis();
					} else {
						setVisible(false);
						new Login_Main().setVisible(true);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btMain.setBounds(0, 0, 100, 29);
		contentPane.add(btMain);
		
		txtInformation = new JTextField();
		txtInformation.setText("Information");
		txtInformation.setHorizontalAlignment(SwingConstants.CENTER);
		txtInformation.setFont(new Font("����", Font.BOLD, 30));
		txtInformation.setEnabled(false);
		txtInformation.setColumns(10);
		txtInformation.setBounds(230, 10, 176, 35);
		contentPane.add(txtInformation);
		
		JButton btWReview = new JButton("\uB9AC\uBDF0\uC4F0\uAE30");
		btWReview.setBackground(Color.WHITE);
		btWReview.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WBMain.dbConnect();
				try {
					WBMain.query("select", "select * from member where id = '"+Main.idStr+"'");
					if(WBMain.rs.next() == false){
						JOptionPane.showMessageDialog(null, "�α����� ���ּ���.");
						WBMain.dbDis();
					} else {
						setVisible(false);
						new ReviewWrite().setVisible(true);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btWReview.setBounds(528, 31, 100, 29);
		contentPane.add(btWReview);
		
		String[] head = {"page", "�ۼ���", "����", "����"};
		DefaultTableModel model = new DefaultTableModel(head,0);
		table = new JTable(model);
		//--------------page�� �����---------------
		table.getColumn("page").setWidth(0);
		table.getColumn("page").setMinWidth(0);
		table.getColumn("page").setMaxWidth(0); 
		//---------------------------------------
		table.getColumnModel().getColumn(1).setPreferredWidth(150); //JTable �� �÷� ���� ����
		table.getColumnModel().getColumn(2).setPreferredWidth(600);
		table.getColumnModel().getColumn(3).setPreferredWidth(100);


		table.addMouseListener(new MouseListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				search = (String) table.getValueAt(table.getSelectedRow(), 0);
				/*WBMain.dbConnect();
				try {
					WBMain.query("select", "select * from review where pageNumber = '"+search+"'");
					//while(WBMain.rs.next()) 
						//Main.movieNum = WBMain.rs.getInt("movieNumber");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				WBMain.dbDis();
				*/
				setVisible(false);
				new Review().setVisible(true);
			}
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mousePressed(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
		});
		
		//��ũ�� ����
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 465, 618, 190);
		scrollPane.setBackground(Color.white);
		contentPane.add(scrollPane);
		
		
		//_--------------------------------------------------------------------------------------------------------
		WBMain.dbConnect();
		try {
			WBMain.query("select", "select * from movie where movieNumber like '"+Main.movieNum+"'");
			while(WBMain.rs.next()) {
				movieName = WBMain.rs.getString("movieName");
				
				txtMvName.setText(WBMain.rs.getString("movieName"));
				txtDirector.setText(WBMain.rs.getString("director"));
				txtGenre.setText(WBMain.rs.getString("genre"));
				txtDate.setText(WBMain.rs.getString("releaseDate"));
				txtRTime.setText(WBMain.rs.getString("runningTime"));
				txtCountry.setText(WBMain.rs.getString("country"));
				txtRating.setText(WBMain.rs.getString("rating"));
				txtPlot.setText(WBMain.rs.getString("moviePlot"));
				
			};
			
			WBMain.query("select", "select * from review where movieNumber like '"+Main.movieNum+"'");
			while(WBMain.rs.next()) {
				model.addRow(new Object[] {
						WBMain.rs.getString("pageNumber"),
						WBMain.rs.getString("name"),
						WBMain.rs.getString("reviewContents"),
						WBMain.rs.getString("rating")
					});
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		WBMain.dbDis();
		//---------------------------------------------------------------------------------------------------
		txtPlot.setCaretPosition(0);
	}
}



