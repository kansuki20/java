import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class MyStatus extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTable table;
	
	static String searchMy = null;  
	
	public MyStatus() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		textField = new JTextField();
		textField.setBackground(Color.WHITE);
		textField.setText("\uD68C\uC6D0\uC815\uBCF4");
		textField.setFont(new Font("����", Font.BOLD, 30));
		textField.setEnabled(false);
		textField.setColumns(10);
		textField.setBounds(214, 10, 135, 43);
		contentPane.add(textField);
		
		JButton btMain = new JButton("Main");
		btMain.setBackground(Color.WHITE);
		btMain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Login_Main().setVisible(true);
			}
		});
		btMain.setBounds(0, 0, 100, 29);
		contentPane.add(btMain);
		
		JLabel lblNewLabel = new JLabel("My Review");
		lblNewLabel.setBounds(20, 76, 94, 29);
		contentPane.add(lblNewLabel);
		//-----------------------------------------------
		String[] head = {"page", "��ȭ��", "����"};
		DefaultTableModel model = new DefaultTableModel(head,0);
		table = new JTable(model);
		//--------------page�� �����---------------
		table.getColumn("page").setWidth(0);
		table.getColumn("page").setMinWidth(0);
		table.getColumn("page").setMaxWidth(0); 
		//---------------------------------------
		table.getColumnModel().getColumn(1).setPreferredWidth(100); //JTable �� �÷� ���� ����
		table.getColumnModel().getColumn(2).setPreferredWidth(500);
		table.addMouseListener(new MouseListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				searchMy = (String) table.getValueAt(table.getSelectedRow(), 0);

				setVisible(false);
				new MyReview().setVisible(true);
			}
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mousePressed(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
		});
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(20, 104, 388, 351);
		contentPane.add(scrollPane);
		
		try {
			WBMain.query("select", "select * from review where id like '"+Main.idStr+"'");
			while(WBMain.rs.next()) {
				model.addRow(new Object[] {
					WBMain.rs.getString("pageNumber"),
					WBMain.rs.getString("movieName"),
					WBMain.rs.getString("reviewContents")
				});
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
}
