import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;


public class Review extends JFrame {

	
	private JPanel contentPane;
	private JTextArea txtReview;
	private JTextArea txtMember;
	private JTextField txtM_Name;


	/**
	 * Launch the application
	/**
	 * Create the frame.
	 */
	public Review() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JButton btMain = new JButton("Main");
		btMain.setBackground(Color.WHITE);
		btMain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WBMain.dbConnect();
				try {
					WBMain.query("select", "select * from member where id = '"+Main.idStr+"'");
					if(WBMain.rs.next() == false){
						setVisible(false);
						new Main().setVisible(true);
						WBMain.dbDis();
					} else {
						setVisible(false);
						new Login_Main().setVisible(true);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btMain.setBounds(0, 0, 100, 29);
		contentPane.add(btMain);
		
		JButton btInfo = new JButton("\uC601\uD654\uC815\uBCF4");
		btInfo.setBackground(Color.WHITE);
		btInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Information().setVisible(true);
			}
		});
		btInfo.setBounds(110, 0, 100, 29);
		contentPane.add(btInfo);
		
		JButton btStatus = new JButton("\uB098\uC758 \uC815\uBCF4");
		btStatus.setBackground(Color.WHITE);
		btStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WBMain.dbConnect();
				try {
					WBMain.query("select", "select * from member where id = '"+Main.idStr+"'");
					if(WBMain.rs.next() == false){
						JOptionPane.showMessageDialog(null, "�α����� ���ּ���.");
						WBMain.dbDis();
					} else {
						setVisible(false);
						new MyStatus().setVisible(true);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btStatus.setBounds(488, 0, 100, 29);
		contentPane.add(btStatus);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		panel.setBounds(20, 39, 558, 416);
		contentPane.add(panel);
		
		JLabel lblReview = new JLabel("REVIEW");
		lblReview.setHorizontalAlignment(SwingConstants.CENTER);
		lblReview.setFont(new Font("����", Font.BOLD, 20));
		lblReview.setBounds(234, 5, 121, 25);
		panel.add(lblReview);
		
		txtReview = new JTextArea();
		txtReview.setBounds(10, 40, 538, 366);
		panel.add(txtReview);
		txtReview.setColumns(10);
		txtReview.setLineWrap(true);
		
		txtMember = new JTextArea();
		txtMember.setBounds(460, 14, 88, 21);
		panel.add(txtMember);
		txtMember.setColumns(10);
		
		txtM_Name = new JTextField();
		txtM_Name.setHorizontalAlignment(SwingConstants.CENTER);
		txtM_Name.setText(Information.movieName);
		txtM_Name.setBounds(10, 12, 96, 21);
		panel.add(txtM_Name);
		txtM_Name.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\uC791\uC131\uC790 : ");
		lblNewLabel.setBounds(415, 10, 55, 25);
		panel.add(lblNewLabel);
		WBMain.dbConnect();
		try {
			WBMain.query("select", "select * from review where pageNumber like '"+Information.search+"'");
			while(WBMain.rs.next()) {
				txtMember.setText(WBMain.rs.getString("name")); //���� ���̺� - �ۼ��� id �����ͺ��̽����� ��������
				txtReview.setText(WBMain.rs.getString("reviewContents"));
			};
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		WBMain.dbDis();
	}

}
