import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class MyReview extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextArea txtReview;
	private JTextArea txtMember;
	private JTextField txtM_Name;
	
	private JRadioButton rdbt1;
	private JRadioButton rdbt2;
	private JRadioButton rdbt3;
	private JRadioButton rdbt4;
	private JRadioButton rdbt5;
	
	int radioValue = 0;

	public MyReview() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JButton btMain = new JButton("Main");
		btMain.setBackground(Color.WHITE);
		btMain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Login_Main().setVisible(true);
			}
		});
		btMain.setBounds(0, 0, 100, 29);
		contentPane.add(btMain);
		
		JButton btInfo = new JButton("\uC601\uD654\uC815\uBCF4");
		btInfo.setBackground(Color.WHITE);
		btInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Information().setVisible(true);
			}
		});
		btInfo.setBounds(110, 0, 100, 29);
		contentPane.add(btInfo);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		panel.setBounds(20, 39, 558, 416);
		contentPane.add(panel);
		
		JLabel lblReview = new JLabel("REVIEW");
		lblReview.setHorizontalAlignment(SwingConstants.CENTER);
		lblReview.setFont(new Font("����", Font.BOLD, 20));
		lblReview.setBounds(234, 5, 121, 25);
		panel.add(lblReview);
		
		txtReview = new JTextArea();
		txtReview.setBounds(10, 40, 538, 297);
		panel.add(txtReview);
		txtReview.setColumns(10);
		txtReview.setLineWrap(true);
		
		txtMember = new JTextArea();
		txtMember.setBounds(460, 14, 88, 21);
		panel.add(txtMember);
		txtMember.setColumns(10);
		
		txtM_Name = new JTextField();
		txtM_Name.setBounds(10, 12, 96, 21);
		panel.add(txtM_Name);
		txtM_Name.setColumns(10);
		//---------------------���� ��¥-----------------------------
		java.sql.Date date = new java.sql.Date(new java.util.Date().getTime());
		
		JButton btR_Correction = new JButton("\uB9AC\uBDF0 \uC218\uC815");
		btR_Correction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					WBMain.query("update", "update review set reviewContents = '"+txtReview.getText()+"', "
							+ "rating = '"+radioValue+"' where pageNumber = '"+MyStatus.searchMy+"'");
					setVisible(false);
					JOptionPane.showMessageDialog(null, "�����Ǿ����ϴ�");
					new MyStatus().setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btR_Correction.setBackground(Color.WHITE);
		btR_Correction.setBounds(0, 377, 100, 29);
		panel.add(btR_Correction);
		
		JButton btR_Remove = new JButton("\uC0AD\uC81C");
		btR_Remove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					WBMain.query("delete", "delete from review where pageNumber = '"+MyStatus.searchMy+"'");
					setVisible(false);
					JOptionPane.showMessageDialog(null, "�����Ǿ����ϴ�");
					new MyStatus().setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btR_Remove.setBackground(Color.WHITE);
		btR_Remove.setBounds(101, 377, 100, 29);
		panel.add(btR_Remove);
		
		JButton btR_Cancel = new JButton("\uCDE8\uC18C");
		btR_Cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new MyStatus().setVisible(true);
			}
		});
		btR_Cancel.setBackground(Color.WHITE);
		btR_Cancel.setBounds(447, 377, 100, 29);
		panel.add(btR_Cancel);
		
		JLabel lblNewLabel = new JLabel("\uC791\uC131\uC790 : ");
		lblNewLabel.setBounds(415, 10, 55, 25);
		panel.add(lblNewLabel);
		
		
		
		rdbt1 = new JRadioButton("1");
		rdbt1.setBackground(Color.WHITE);
		rdbt1.setBounds(385, 343, 33, 23);
		rdbt1.addActionListener(this);
		panel.add(rdbt1);
		
		rdbt2 = new JRadioButton("2");
		rdbt2.setBackground(Color.WHITE);
		rdbt2.setBounds(420, 343, 33, 23);
		rdbt2.addActionListener(this);
		panel.add(rdbt2);
		
		rdbt3 = new JRadioButton("3");
		rdbt3.setBackground(Color.WHITE);
		rdbt3.setBounds(455, 343, 33, 23);
		rdbt3.addActionListener(this);
		panel.add(rdbt3);
		
		rdbt4 = new JRadioButton("4");
		rdbt4.setBackground(Color.WHITE);
		rdbt4.setBounds(490, 343, 33, 23);
		rdbt4.addActionListener(this);
		panel.add(rdbt4);
		
		rdbt5 = new JRadioButton("5");
		rdbt5.setBackground(Color.WHITE);
		rdbt5.setBounds(525, 343, 33, 23);
		rdbt5.addActionListener(this);
		panel.add(rdbt5);

		ButtonGroup group = new ButtonGroup();
		group.add(rdbt1);
		group.add(rdbt2);
		group.add(rdbt3);
		group.add(rdbt4);
		group.add(rdbt5);
		
		WBMain.dbConnect();
		try {
			WBMain.query("select", "select * from review where pageNumber like '"+MyStatus.searchMy+"'");
			while(WBMain.rs.next()) {
				txtMember.setText(WBMain.rs.getString("name"));
				txtM_Name.setText(WBMain.rs.getString("movieName"));
				txtReview.setText(WBMain.rs.getString("reviewContents"));
				Main.movieNum = WBMain.rs.getInt("movieNumber");
				switch(WBMain.rs.getInt("rating")) {
					case 1:
						radioValue = 1;
						rdbt1.setSelected(true);
						break;
					case 2:
						radioValue = 2;
						rdbt2.setSelected(true);
						break;
					case 3:
						radioValue = 3;
						rdbt3.setSelected(true);
						break;
					case 4:
						radioValue = 4;
						rdbt4.setSelected(true);
						break;
					case 5:
						radioValue = 5;
						rdbt5.setSelected(true);
						break;
				}
			};
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == rdbt1) 
			radioValue = 1;
		else if (e.getSource() == rdbt2)
			radioValue = 2;
		else if (e.getSource() == rdbt3)
			radioValue = 3;
		else if (e.getSource() == rdbt4)
			radioValue = 4;
		else if (e.getSource() == rdbt5)
			radioValue = 5;
	}
}
