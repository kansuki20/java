import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Color;



public class Membership extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField idField;
	private JTextField psField;
	private JTextField emailField;
	private JTextField textEmail;
	private JTextField textPs;
	private JTextField textId;
	private JTextField userName;
	private JTextField textNickname;
	private JButton btMain;
	
	/*static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;*/


	

	/**
	 * Launch the application.
	 */
	/**
	 * Create the frame.
	 */
	public Membership() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		textField = new JTextField();
		textField.setEnabled(false);
		textField.setText("\uD68C\uC6D0\uAC00\uC785");
		textField.setFont(new Font("����", Font.BOLD, 30));
		textField.setBounds(214, 10, 135, 43);
		contentPane.add(textField);
		textField.setColumns(10);
		
		idField = new JTextField();
		idField.setEnabled(false);
		idField.setFont(new Font("����", Font.PLAIN, 14));
		idField.setHorizontalAlignment(SwingConstants.CENTER);
		idField.setText("id");
		idField.setBounds(116, 112, 96, 21);
		contentPane.add(idField);
		idField.setColumns(10);
		
		psField = new JTextField();
		psField.setFont(new Font("����", Font.PLAIN, 14));
		psField.setEnabled(false);
		psField.setHorizontalAlignment(SwingConstants.CENTER);
		psField.setText("ps");
		psField.setBounds(116, 143, 96, 21);
		contentPane.add(psField);
		psField.setColumns(10);
		
		emailField = new JTextField();
		emailField.setEnabled(false);
		emailField.setHorizontalAlignment(SwingConstants.CENTER);
		emailField.setText("e-mail");
		emailField.setBounds(116, 174, 96, 21);
		contentPane.add(emailField);
		emailField.setColumns(10);
		
		textEmail = new JTextField();
		textEmail.setColumns(10);
		textEmail.setBounds(232, 174, 197, 21);
		contentPane.add(textEmail);
		
		textPs = new JTextField();
		textPs.setColumns(10);
		textPs.setBounds(232, 143, 197, 21);
		contentPane.add(textPs);
		
		textId = new JTextField();
		textId.setColumns(10);
		textId.setBounds(232, 112, 197, 21);
		contentPane.add(textId);
		
		userName = new JTextField();
		userName.setText("\uB2C9\uB124\uC784");
		userName.setHorizontalAlignment(SwingConstants.CENTER);
		userName.setFont(new Font("����", Font.PLAIN, 12));
		userName.setEnabled(false);
		userName.setColumns(10);
		userName.setBounds(116, 81, 96, 21);
		contentPane.add(userName);
		
		textNickname = new JTextField();
		textNickname.setColumns(10);
		textNickname.setBounds(232, 81, 197, 21);
		contentPane.add(textNickname);
		
		JButton btMember = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btMember.setBackground(Color.WHITE);
		btMember.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WBMain.dbConnect();
				try {
					WBMain.query("insert", "insert into member values('"+textId.getText()+"','"+textPs.getText()+"','"+textNickname.getText()+"','"+textEmail.getText()+"')");
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				System.out.println("���׸� �߰��Ϸ�");
				WBMain.dbDis();

				textNickname.setText("");
				textId.setText("");
				textPs.setText("");
				textEmail.setText("");
				
				setVisible(false);
				new Main().setVisible(true);
			}
		});
		btMember.setBounds(208, 223, 93, 23);
		contentPane.add(btMember);
		
		JButton btCancel = new JButton("\uCDE8\uC18C");
		btCancel.setBackground(Color.WHITE);
		btCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				/*WBMain.dbConnect();
				try {
					query("insert", "insert into member values('"+a+"','"+name_t.getText()+"','"+telNo_t.getText()+"')");
				}*/
				setVisible(false);
				new Main().setVisible(true);
			}
		});
		btCancel.setBounds(336, 223, 93, 23);
		contentPane.add(btCancel);
		
		btMain = new JButton("Main");
		btMain.setBackground(Color.WHITE);
		btMain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Main().setVisible(true);
			}
		});
		btMain.setBounds(0, 0, 100, 29);
		contentPane.add(btMain);
	}
}
