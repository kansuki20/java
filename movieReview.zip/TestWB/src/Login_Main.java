import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JTextPane;

public class Login_Main extends JFrame {

	private JPanel contentPane;
	private JTextField txtMain;
	private JTextField txtSearch;
	private JButton btSearch;
	private JTextField nickNameField;
	
	private JScrollPane scrollPane;
	private JTable table;
	
	

	public Login_Main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		txtMain = new JTextField();
		txtMain.setEnabled(false);
		txtMain.setFont(new Font("����", Font.BOLD, 30));
		txtMain.setHorizontalAlignment(SwingConstants.CENTER);
		txtMain.setText("Main");
		txtMain.setBounds(189, 10, 166, 35);
		contentPane.add(txtMain);
		txtMain.setColumns(10);
		
		txtSearch = new JTextField();
		txtSearch.setText("\uAC80\uC0C9\uD560 \uB0B4\uC6A9\uC744 \uC785\uB825\uD558\uC138\uC694.");
		txtSearch.setBounds(110, 76, 240, 26);
		contentPane.add(txtSearch);
		txtSearch.setColumns(10);
		txtSearch.addMouseListener(new MouseListener() {
			@Override
			public void mousePressed(MouseEvent e) {
				txtSearch.setText("");
			}
			@Override
			public void mouseClicked(MouseEvent e) {
			}
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
		});
		
		String[] head = {"��ȭ��", "����", "���� ����", "������"};
		DefaultTableModel model = new DefaultTableModel(head,0);
		table = new JTable(model);
		table.addMouseListener(new MouseListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String search = (String) table.getValueAt(table.getSelectedRow(), 0);
				WBMain.dbConnect();
				try {
					WBMain.query("select", "select * from movie where movieName = '"+search+"'");
					while(WBMain.rs.next()) 
						Main.movieNum = WBMain.rs.getInt("movieNumber");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				setVisible(false);
				new Information().setVisible(true);
			}
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mousePressed(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
		});
		
		//��ũ�� ����
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 131, 412, 262);
		contentPane.add(scrollPane);
		
		
		//-----------------------------------���̽� ����--------------------
		Choice choice = new Choice();
		choice.setBounds(34, 79, 140, 18);
		choice.add("��ȭ��");
		choice.add("����");
		contentPane.add(choice);
		
		JPanel status = new JPanel();
		status.setBounds(429, 76, 119, 130);
		contentPane.add(status);
		status.setLayout(null);
		
		JButton logOut = new JButton("LogOut");
		logOut.setBackground(Color.WHITE);
		logOut.setBounds(0, 107, 119, 23);
		status.add(logOut);
		
		JButton MyStatus = new JButton("\uB098\uC758\uC815\uBCF4");
		MyStatus.setBackground(Color.WHITE);
		MyStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new MyStatus().setVisible(true);
			}
		});
		MyStatus.setBounds(0, 84, 119, 23);
		status.add(MyStatus);
		
		nickNameField = new JTextField();
		nickNameField.setEnabled(false);
		nickNameField.setBounds(0, 0, 119, 28);
		status.add(nickNameField);
		nickNameField.setColumns(10);
		nickNameField.setText(Main.name);

		/*try {
			//WBMain.query("select", "select * from member");
			nickNameField.setText(WBMain.rs.getString(3));
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/

		logOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WBMain.dbDis();
				Main.idStr = null;
				Main.name = null;
				setVisible(false);
				new Main().setVisible(true);
				
			}
		});
		
		btSearch = new JButton("\uAC80\uC0C9");
		btSearch.setBackground(Color.WHITE);
		btSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.setNumRows(0);
				if (choice.getSelectedItem() == "��ȭ��") {
					try {
						WBMain.query("select", "select * from movie where movieName like '%"+txtSearch.getText()+"%'");
						while(WBMain.rs.next()) {
							model.addRow(new Object[] {
								WBMain.rs.getString("movieName"),
								WBMain.rs.getString("director"),
								WBMain.rs.getString("country"),
								WBMain.rs.getString("releaseDate"),
							});
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				} else if (choice.getSelectedItem() == "����") {
					try {
						WBMain.query("select", "select * from movie where director like '%"+txtSearch.getText()+"%'");
						while(WBMain.rs.next()) {
							model.addRow(new Object[] {
								WBMain.rs.getString("movieName"),
								WBMain.rs.getString("director"),
								WBMain.rs.getString("country"),
								WBMain.rs.getString("releaseDate"),
							});
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		
		btSearch.setBounds(349, 75, 59, 26);
		contentPane.add(btSearch);

	}
	
}
