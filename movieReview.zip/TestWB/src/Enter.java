import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class Enter extends JFrame {

	private JPanel contentPane;
	private JTextField movieName;
	private JTextField director;
	private JTextField releaseDate;
	private JTextField runningTime;
	private JTextField country;
	private JTextField genre;
	private JTextField rating;
	private JTextField posterLink;


	public Enter() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1033, 657);
		contentPane = new JPanel();
		contentPane.setLayout(null);
		setContentPane(contentPane);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 699, 571);
		contentPane.add(scrollPane);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		
		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setLineWrap(true);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WBMain.dbConnect();
				try {
					WBMain.query("insert", "insert into movie (movieName, moviePlot, director, releaseDate, runningTime, country, genre, rating, posterLink)"
							+ "values('"+movieName.getText()+"','"+textArea.getText()+"','"+director.getText()+"','"+releaseDate.getText()+"','"+runningTime.getText()+"', '"+country.getText()+"', '"+genre.getText()+"', '"+rating.getText()+"', '"+""+"')");
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				WBMain.dbDis();
			}
		});
		btnNewButton.setBounds(719, 438, 93, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New button");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Main().setVisible(true);
			}
		});
		btnNewButton_1.setBounds(844, 438, 93, 23);
		contentPane.add(btnNewButton_1);
		
		movieName = new JTextField();
		movieName.setBounds(785, 13, 226, 21);
		contentPane.add(movieName);
		movieName.setColumns(10);
		
		director = new JTextField();
		director.setColumns(10);
		director.setBounds(785, 44, 226, 21);
		contentPane.add(director);
		
		releaseDate = new JTextField();
		releaseDate.setColumns(10);
		releaseDate.setBounds(785, 75, 226, 21);
		contentPane.add(releaseDate);
		
		runningTime = new JTextField();
		runningTime.setColumns(10);
		runningTime.setBounds(785, 106, 226, 21);
		contentPane.add(runningTime);
		
		country = new JTextField();
		country.setColumns(10);
		country.setBounds(785, 137, 226, 21);
		contentPane.add(country);
		
		genre = new JTextField();
		genre.setColumns(10);
		genre.setBounds(785, 168, 226, 21);
		contentPane.add(genre);
		
		rating = new JTextField();
		rating.setColumns(10);
		rating.setBounds(785, 199, 226, 21);
		contentPane.add(rating);
		
		posterLink = new JTextField();
		posterLink.setColumns(10);
		posterLink.setBounds(719, 230, 292, 75);
		contentPane.add(posterLink);
		
		JLabel lblNewLabel = new JLabel("name");
		lblNewLabel.setBounds(719, 16, 56, 21);
		contentPane.add(lblNewLabel);
		
		JLabel lblDirector = new JLabel("director");
		lblDirector.setBounds(719, 44, 56, 21);
		contentPane.add(lblDirector);
		
		JLabel lblReleasedate = new JLabel("date");
		lblReleasedate.setBounds(719, 75, 56, 21);
		contentPane.add(lblReleasedate);
		
		JLabel lblRuntime = new JLabel("runTime");
		lblRuntime.setBounds(719, 106, 56, 21);
		contentPane.add(lblRuntime);
		
		JLabel lblCountry = new JLabel("country");
		lblCountry.setBounds(719, 137, 56, 21);
		contentPane.add(lblCountry);
		
		JLabel lblGenre = new JLabel("genre");
		lblGenre.setBounds(719, 168, 56, 21);
		contentPane.add(lblGenre);
		
		JLabel lblRating = new JLabel("rating");
		lblRating.setBounds(719, 199, 56, 21);
		contentPane.add(lblRating);
		
		JLabel lblLink = new JLabel("link");
		lblLink.setBounds(719, 305, 56, 21);
		contentPane.add(lblLink);
		

	}
}
